extern const unsigned short configStreamLen;
extern const dataArr st_twConfig[];
