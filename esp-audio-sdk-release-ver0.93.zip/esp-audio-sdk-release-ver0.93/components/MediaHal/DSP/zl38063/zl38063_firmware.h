#ifndef __ZL380xx_FIRMWARE_H__
#define __ZL380xx_FIRMWARE_H__

extern const twFwr st_twFirmware[];
extern const unsigned short firmwareStreamLen;
extern const unsigned long programBaseAddress;
extern const unsigned long executionAddress;
extern const unsigned char haveProgramBaseAddress;

#endif
