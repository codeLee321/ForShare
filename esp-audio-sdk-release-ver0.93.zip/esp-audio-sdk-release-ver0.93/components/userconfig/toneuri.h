/*
 * ESPRESSIF MIT License
 *
 * Copyright (c) 2018 <ESPRESSIF SYSTEMS (SHANGHAI) PTE LTD>
 *
 * Permission is hereby granted for use on all ESPRESSIF SYSTEMS products, in which case,
 * it is free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the Software is furnished
 * to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 */

#ifndef __TONEURI_H__
#define __TONEURI_H__

extern const char* tone_uri[];

typedef enum {
    TONE_TYPE_BT_RECONNECT,
    TONE_TYPE_WECHAT,
    TONE_TYPE_WELCOME_TO_WIFI,
    TONE_TYPE_NEW_VERSION_AVAILABLE,
    TONE_TYPE_BT_SUCCESS,
    TONE_TYPE_FREETALK,
    TONE_TYPE_UPGRADE_DONE,
    TONE_TYPE_SHUTDOWN,
    TONE_TYPE_ALARM,
    TONE_TYPE_WIFI_SUCCESS,
    TONE_TYPE_UNDER_SMARTCONFIG,
    TONE_TYPE_OUT_OF_POWER,
    TONE_TYPE_SERVER_CONNECT,
    TONE_TYPE_HELLO,
    TONE_TYPE_PLEASE_RETRY_WIFI,
    TONE_TYPE_PLEASE_SETTING_WIFI,
    TONE_TYPE_WELCOME_TO_BT,
    TONE_TYPE_WIFI_TIME_OUT,
    TONE_TYPE_WIFI_RECONNECT,
    TONE_TYPE_SERVER_DISCONNECT,
    TONE_TYPE_MAX,
} ToneType;

int getToneUriMaxIndex();

#endif /* __TONEURI_H__ */
